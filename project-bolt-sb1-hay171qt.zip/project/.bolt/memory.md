# Project memory

## Product intent & audience

- Website for **GLANVIA Gebäudereinigung**, a German cleaning company (Einzelunternehmen) targeting private and commercial clients in Germany.
- All UI content, navigation, buttons, forms, and legal pages must be in **professional German (Germany)**.
- Core goals: premium presentation, real service photography, lead generation via a multi-step quote request form, and easy contact (phone, email, WhatsApp).

## Brand personality & voice

- Premium, professional, trustworthy, personal (“Inhaber persönlich hinter jedem Auftrag”).
- Tone: clear, confident, fair. Emphasis on personal care, direct quality control, efficient structure, and fair pricing.
- Exact about text and headline are provided; do not paraphrase or invent company claims/certifications/reviews/employees.

## Visual design & UX direction

- Palette: **blue, white, dark grey**.
- Original GLANVIA logo must be used **large and unmodified**: never redesign, crop, distort, or place inside a white box; keep unboxed on dark footer.
- Clean, elegant typography with generous spacing; smooth animations and transitions.
- Mobile-first, responsive from 320px to desktop; excellent mobile experience.
- Modern service cards and premium navigation.
- Use real high-resolution professional photos (Unsplash/Pexels) for each service: Büroreinigung, Glasreinigung, Treppenhausreinigung, Grundreinigung, Baureinigung, Schulreinigung, Gebäudereinigung, Privathaushalte. No grey boxes, placeholders, illustrations, or generic gradients in place of photos.
- Floating green WhatsApp button on every page (mobile + desktop), plus clickable phone and email links.

## Decisions, constraints & rationale

- Stack: **Vite + React + TypeScript + Tailwind CSS**, icons via `lucide-react`, `@/` import alias. No extra UI theme/icon packages unless requested. (Global `.bolt/prompt` instructions apply.)
- Pages: Startseite, Leistungen, Privatkunden, Gewerbekunden, Über uns, Angebot anfordern, Kontakt, Impressum, Datenschutzerklärung.
- Homepage includes a premium hero with large headline, cleaning photo, and clear CTAs.
- Seven-step quote form on “Angebot anfordern”: customer type → services → property details → photo upload (JPG/JPEG/PNG/WEBP with previews + delete) → work description → contact details + preferred contact method → summary + GDPR consent + submit “Anfrage absenden”. No automatic/binding prices.
- Supabase integration prepared for secure form submissions and **private** photo storage; server-side validation; browser grants limited to submitting only. If backend needs configuration, explain rather than simulate.
- Social links limited to Facebook, Instagram, TikTok (open in new tabs); contact page includes Google Maps and clickable phone/email.
- Legal pages use provided company info only; GDPR info covers contact forms, photo uploads, storage, cookies, WhatsApp, analytics where applicable.
- Company details: Hamoud Alahmad (owner), Hirschbergstraße 40, 71634 Ludwigsburg; +49 163 7845182; info@glanvia.de; https://glanvia.de; VAT DE466493667. WhatsApp: https://wa.me/491637845182.
- Build must pass lint/type checks; do **not** publish without user approval.

## Open questions & assumptions

- Assumes stable Unsplash/Pexels image URLs remain valid; photo provider was temporarily unavailable, so direct Unsplash assets were used.
- Supabase project/tables/buckets assumed configured; production credentials and email/notification routing still need user confirmation.
- No backend for contact/quote forms beyond Supabase; form delivery/confirmation emails not yet specified.
- Analytics tools not specified despite GDPR mention; currently none assumed.